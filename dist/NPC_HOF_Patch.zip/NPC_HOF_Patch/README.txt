﻿====================================================================
  NPC Friends x Heap of Foods - 요리 연동 패치
====================================================================

NPC Friends 의 왈리 NPC 가 Heap of Foods 를 비롯한 음식 모드의 요리를
전부 인식하고, 여러 가지 요리를 돌아가며 만들도록 고쳐 줍니다.


[ 무엇이 문제였나 ]

  NPC Friends 는 "왈리가 만들 수 있는 요리" 목록을 모드 안에 손으로
  적어 두었습니다 (scripts/npc/npc_cooking_recipes.lua).
  거기에는 바닐라 요리와 일부 모드 요리만 들어 있어서, Heap of Foods 가
  추가한 200종이 넘는 요리는 창고에 재료가 아무리 많아도 후보에 오르지
  않습니다.

  게다가 요리를 고르는 함수 맨 앞에 "창고에 미트볼이 없으면 무조건
  미트볼부터" 라는 규칙이 박혀 있어서, 같은 요리만 계속 나옵니다.


[ 이 패치가 하는 일 ]

  요리 목록을 200개 더 적어 넣는 대신, 왈리가 쓸 수 있는 재료로 조합을
  만들어 보고 게임 자체의 요리 판정 함수(cooking.CalculateRecipe)에
  "이 조합은 무슨 요리가 되나?" 하고 직접 물어봅니다.

  그래서 정상적인 방법으로 등록된 음식 모드라면 무엇이든 자동으로
  인식됩니다. Heap of Foods 가 업데이트로 요리를 더 추가해도 이 패치는
  그대로 두면 됩니다.

  여기에 "최근에 만든 요리"와 "이미 창고에 쌓인 요리"에 감점을 주어
  메뉴가 계속 바뀌도록 했습니다.


[ 설치 ]

  1. 이 zip 을 폴더째 압축 해제합니다. (압축 안에서 바로 실행하면 안 됩니다)
  2. DST 를 완전히 종료합니다.
  3. install.bat 을 더블클릭합니다.
  4. DST 를 다시 실행하고, Heap of Foods 와 NPC Friends 를 둘 다 켠 채로
     월드에 들어갑니다.
  5. 왈리 NPC 에게 냄비와 아이스박스를 지정하고 요리를 시켜 봅니다.

  권한 오류가 나면 install.bat 을 마우스 오른쪽 클릭 ->
  "관리자 권한으로 실행" 을 해 주세요.


[ 되돌리기 ]

  restore.bat 을 더블클릭하면 원래대로 돌아갑니다.
  원본은 설치할 때 _backup 폴더에 보관됩니다.


[ 설정 바꾸기 ]

  files\npc_hof_cooking.lua 를 메모장으로 열면 맨 위에 USER_SETTINGS 가
  있습니다. 값을 고친 뒤 install.bat 을 다시 실행하면 적용됩니다.

    variety        요리 다양성   "off" / "low" / "medium" / "high"
    budget         탐색량        "low" / "medium" / "high"
    same_dish_max  같은 요리를 창고에 몇 개까지 쌓을지 (0 = 모드 설정 따름)
    allow_negative 체력/정신력이 깎이는 요리도 만들지
    debug          서버 로그에 고른 이유를 출력 (문제 확인용)


[ 알아두실 점 ]

  * Steam 이 NPC Friends 를 업데이트하면 이 패치는 지워집니다.
    그때는 install.bat 을 다시 한 번 실행해 주세요.

  * 멀티에서는 서버(호스트) 쪽에 설치되어 있어야 효과가 있습니다.
    NPC 의 요리 판단은 전부 서버에서 이루어지기 때문입니다.

  * 건드리는 파일은 scripts/npc/npc_cooking_planner.lua 하나뿐이고,
    그것도 맨 끝에 아래 한 줄을 넣는 것이 전부입니다.

      pcall(function() require("npc/npc_hof_cooking").Install(CookingPlanner) end)

  * 문제가 생기면 USER_SETTINGS 의 debug 를 true 로 바꾸고 서버 로그의
    [NPCF-HOF] 줄을 확인해 주세요.
